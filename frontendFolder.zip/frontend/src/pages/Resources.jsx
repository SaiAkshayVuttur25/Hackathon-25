/*import React, { useState, useEffect } from "react";
import Navbar from "../components/Navbar";
import ResourceCard from "../components/Resourcecard";
import axios from "axios";
import { Spinner } from "@chakra-ui/react";

function Resources(props) {
  const [data, setData] = useState(null);
  const [callCount, setCallCount] = useState(0);

  useEffect(() => {
    if (callCount === 0) {
      axios.get("https://aac-backend-25.onrender.com/resource/getResources").then((res) => {
        setData(() => {
          let temp = res.data.data;
          temp.reverse();
          return temp;
        });
        setCallCount(1);
      });
    }
  });

  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  return (
      <div className="blog-bg bg-black min-h-screen">
        <Navbar {...props} />
        <h1 className="w-3/4 mx-auto rounded-lg p-3 text-center text-2xl mt-5 mb-5 bg-gray-800 shadow-lg text-white">
          Shared Resources
        </h1>
        {data === null ? (
            <div className="text-center">
              <h1 className="text-center text-xl mt-32 mb-32">
                <Spinner className="m-4" size="xl"/>
                <br/>
                <span className="">This may take time, Please Wait...</span>
              </h1>
            </div>
        ) : data.length === 0 ? (
            <div className="text-center">
              <h1 className="text-center text-xl mt-32 mb-32">
                <span className="">NO RECORDS FOUND</span>
              </h1>
            </div>
        ) : (
            <div className="md:p-5 d-block flex-column justify-content-center flex-wrap">
              {data.map((resource, index) => {
                return (
                    <div key={index} className="m-1">
                      <ResourceCard data={resource}/>
                    </div>
                );
              })}
            </div>
        )}
      </div>
  );
}

export default Resources;
*/

// import React, { useState } from 'react';
// import { Calendar, momentLocalizer } from 'react-big-calendar';
// import moment from 'moment';
// import 'react-big-calendar/lib/css/react-big-calendar.css';

// const localizer = momentLocalizer(moment);

// const Resources = () => {
//   const [events, setEvents] = useState([
//     {
//       title: 'Sample Event',
//       start: new Date(2025, 0, 22, 10, 0),
//       end: new Date(2025, 0, 22, 12, 0),
//     },
//   ]);

//   const [newEvent, setNewEvent] = useState({ title: '', start: '', end: '' });

//   // Function to handle input changes
//   const handleInputChange = (e) => {
//     const { name, value } = e.target;
//     setNewEvent((prev) => ({ ...prev, [name]: value }));
//   };

//   // Function to add the event
//   const handleAddEvent = () => {
//     const startDate = new Date(newEvent.start);
//     const endDate = new Date(newEvent.end);

//     if (!newEvent.title || isNaN(startDate) || isNaN(endDate)) {
//       alert('Please provide a valid title, start date, and end date!');
//       return;
//     }

//     setEvents((prevEvents) => [
//       ...prevEvents,
//       { title: newEvent.title, start: startDate, end: endDate },
//     ]);

//     setNewEvent({ title: '', start: '', end: '' });
//   };

//   return (
//     <div style={{ margin: '20px' }}>
//       <h2>Resources Page</h2>

//       {/* Event Form */}
//       <div style={{ marginBottom: '20px' }}>
//         <h3>Add New Event</h3>
//         <input
//           type="text"
//           name="title"
//           placeholder="Event Title"
//           value={newEvent.title}
//           onChange={handleInputChange}
//           style={{ marginRight: '10px' }}
//         />
//         <input
//           type="datetime-local"
//           name="start"
//           value={newEvent.start}
//           onChange={handleInputChange}
//           style={{ marginRight: '10px' }}
//         />
//         <input
//           type="datetime-local"
//           name="end"
//           value={newEvent.end}
//           onChange={handleInputChange}
//           style={{ marginRight: '10px' }}
//         />
//         <button onClick={handleAddEvent}>Add Event</button>
//       </div>

//       {/* Calendar */}
//       <div style={{ height: '500px' }}>
//         <Calendar
//           localizer={localizer}
//           events={events}
//           startAccessor="start"
//           endAccessor="end"
//           style={{ height: 500 }}
//         />
//       </div>
//     </div>
//   );
// };

// export default Resources;

//------------------------------------------------------------------------------------------------------------
import React, { useState } from 'react';
import { Calendar, momentLocalizer } from 'react-big-calendar';
import moment from 'moment';
import 'react-big-calendar/lib/css/react-big-calendar.css';
import Navbar from "../components/Navbar";
import axios from "axios";
import { Spinner } from "@chakra-ui/react";

// Initialize moment localizer
const localizer = momentLocalizer(moment);

const Resources = (props) => {
  // State to store calendar events
  const [events, setEvents] = useState([
    {
      title: 'IDS Event',
      start: new Date(2025, 0, 22, 10, 0), // Jan 22, 2025, 10:00 AM
      end: new Date(2025, 0, 22, 12, 0),   // Jan 22, 2025, 12:00 PM
    },
  ]);

  // State to manage the new event being added
  const [newEvent, setNewEvent] = useState({ title: '', start: '', end: '' });

  // Function to handle input changes for the new event form
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setNewEvent((prev) => ({ ...prev, [name]: value }));
  };

  // Function to add a new event to the calendar
  const handleAddEvent = () => {
    const startDate = new Date(newEvent.start);
    const endDate = new Date(newEvent.end);

    // Validate input fields
    if (!newEvent.title || isNaN(startDate) || isNaN(endDate) || startDate >= endDate) {
      alert('Please provide a valid title, start date, and end date (end must be after start).');
      return;
    }

    // Add the new event
    setEvents((prevEvents) => [
      ...prevEvents,
      { title: newEvent.title, start: startDate, end: endDate },
    ]);

    // Reset new event form
    setNewEvent({ title: '', start: '', end: '' });
  };

  // Sample user data (make sure to pass the actual user data here)
  const user = { isAdmin: true }; // This should be passed from parent or context

  return (
    <div >
      <Navbar user={user} /> {/* Pass user data to Navbar */}
      <div className="mt-5 mx-5 mb-5 p-6 bg-gray-800 rounded-xl shadow-lg">
  <h3 className="text-xl font-semibold text-white mb-4">Add New Event</h3>
  <div className="mb-4">
    <label htmlFor="title" className="block text-gray-300 text-sm font-medium mb-2">
      Event Title
    </label>
    <input
      type="text"
      id="title"
      name="title"
      placeholder="Enter Event Title"
      value={newEvent.title}
      onChange={handleInputChange}
      className="w-full p-3 bg-gray-700 text-white border border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
    />
  </div>
  <div className="mb-4">
    <label htmlFor="start" className="block text-gray-300 text-sm font-medium mb-2">
      Starting Day
    </label>
    <input
      type="datetime-local"
      id="start"
      name="start"
      value={newEvent.start}
      onChange={handleInputChange}
      className="w-full p-3 bg-gray-700 text-white border border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
    />
  </div>
  <div className="mb-4">
    <label htmlFor="end" className="block text-gray-300 text-sm font-medium mb-2">
      Ending Day
    </label>
    <input
      type="datetime-local"
      id="end"
      name="end"
      value={newEvent.end}
      onChange={handleInputChange}
      className="w-full p-3 bg-gray-700 text-white border border-gray-600 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
    />
  </div>
  <button
    onClick={handleAddEvent}
    className="px-6 py-3 bg-blue-600 text-white font-semibold rounded-lg shadow-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2"
  >
    Add Event
  </button>
</div>


      {/* Calendar Component */}
      <div style={{ height: '500px' }}>
        <Calendar
          localizer={localizer}
          events={events}
          startAccessor="start"
          endAccessor="end"
          style={{ height: 500, border: '1px solid #ddd', borderRadius: '5px' }}
        />
      </div>
    </div>
  );
};

export default Resources;
